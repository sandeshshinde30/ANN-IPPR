# 13) Write a code for demonstrating Image Transformation from spatial
# domain into frequency domain. Apply DCT transformation. Display Original
# Image and Image retried after inverse (IDCT) transform
# Input: 24 bit RGB image
# Expected Output: PSNR value comparing Original Image and IDCT Image

import cv2
import numpy as np

# Load the image
image = cv2.imread('input_image.jpg')  # Replace with your image path

if image is None:
    print("Error: Image not found or could not be opened.")
    exit()

# Convert image to grayscale for DCT processing
gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Apply DCT transformation
dct = cv2.dct(np.float32(gray_image))

# Apply inverse DCT (IDCT)
idct = cv2.idct(dct)

# Normalize the IDCT result to uint8 for comparison with the original image
idct_uint8 = cv2.normalize(idct, None, 0, 255, cv2.NORM_MINMAX)
idct_uint8 = np.uint8(idct_uint8)

# Compute PSNR between original and IDCT image (convert to float32 for PSNR calculation)
psnr_value = cv2.PSNR(np.float32(gray_image), np.float32(idct_uint8))

# Display images
cv2.imshow("Original Image", gray_image)
cv2.imshow("Image after IDCT", idct_uint8)

print(f"PSNR between Original and IDCT Image: {psnr_value} dB")

cv2.waitKey(0)
cv2.destroyAllWindows()

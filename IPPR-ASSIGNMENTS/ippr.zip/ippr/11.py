# 11) Write a code for demonstrating Image transformation: Rotation
# Input: 24 bit RGB image
# Expected Output:
# i) 24 bit RGB image rotated clockwise by 90 degree
# ii) 24 bit RGB image rotated anti-clockwise by 90 degree

###//
import cv2

# Load the image
image = cv2.imread('input_image.jpg')  # Replace with your image path

if image is None:
    print("Error: Image not found or could not be opened.")
    exit()

# Rotate 90 degrees clockwise
rotated_clockwise = cv2.rotate(image, cv2.ROTATE_90_CLOCKWISE)

# Rotate 90 degrees anti-clockwise
rotated_anticlockwise = cv2.rotate(image, cv2.ROTATE_90_COUNTERCLOCKWISE)

# Display the images
cv2.imshow("Original Image", image)
cv2.imshow("Rotated Clockwise", rotated_clockwise)
cv2.imshow("Rotated Anti-Clockwise", rotated_anticlockwise)

# Save the results
cv2.imwrite('rotated_clockwise.jpg', rotated_clockwise)
cv2.imwrite('rotated_anticlockwise.jpg', rotated_anticlockwise)

cv2.waitKey(0)
cv2.destroyAllWindows()

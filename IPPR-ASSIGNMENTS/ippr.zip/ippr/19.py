# 19) Write a code for demonstrating Image arithmetic. Enhance any one color
# channel by multiplying enhancement factor.
# Input: 24 bit RGB image
# Expected output: 24 bit RGB Enhanced 

import cv2
import numpy as np

# Load the RGB image
image = cv2.imread('input_image.jpg')

if image is None:
    print("Error: Image not found or could not be opened.")
    exit()

# Enhance the Red channel by multiplying it with a factor
enhancement_factor = 1.5
enhanced_image = np.copy(image)

# Multiply the red channel (index 2 in BGR) by the enhancement factor
enhanced_image[:, :, 2] = np.clip(enhanced_image[:, :, 2] * enhancement_factor, 0, 255)

# Display the enhanced image
cv2.imshow("Enhanced Image", enhanced_image)
cv2.waitKey(0)
cv2.destroyAllWindows()

# Save the enhanced image
cv2.imwrite('enhanced_image.jpg', enhanced_image)

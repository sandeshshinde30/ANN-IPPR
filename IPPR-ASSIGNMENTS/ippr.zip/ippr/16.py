# 16) Write a code for demonstrating Image Normalization.
# Input: 24 bit RGB image
# Expected output: Normalized 24 bit RGB image

import cv2
import numpy as np

# Load the image
image = cv2.imread('input_image.jpg')

if image is None:
    print("Error: Image not found or could not be opened.")
    exit()

# Normalize the image to range [0, 1]
normalized_image = np.float32(image) / 255.0

# Convert back to uint8 for visualization
normalized_image_uint8 = np.uint8(normalized_image * 255)

# Display the images
cv2.imshow("Normalized Image", normalized_image_uint8)
cv2.waitKey(0)
cv2.destroyAllWindows()

# Save the normalized image
cv2.imwrite('normalized_image.jpg', normalized_image_uint8)

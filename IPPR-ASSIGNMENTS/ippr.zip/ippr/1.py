# 1) Write a code for obtaining negative of the image.
# Input: Gray scale 8 bit image
# Expected output: Gray scale 8 bit image
import cv2

# Load the image in grayscale mode
image = cv2.imread('input_image.jpg', cv2.IMREAD_GRAYSCALE)

# Check if the image loaded properly
if image is None:
    print("Error: Image not found or unable to load.")
else:
    # Calculate the negative image
    negative_image = 255 - image

    # Save or display the result
    cv2.imwrite('negative_image.png', negative_image)
    cv2.imshow('Original Image', image)
    cv2.imshow('Negative Image', negative_image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

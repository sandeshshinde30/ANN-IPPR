# 7) Write a code for obtaining histogram of the image
# Input: 24 bit RGB image
# Expected Output: Three separate histograms for individual RGB channels

import cv2
import matplotlib.pyplot as plt
import numpy as np

# Load image
image = cv2.imread('input_image.jpg')

# Split into R, G, B
channels = cv2.split(image)
colors = ('b', 'g', 'r')
plt.figure()

# Plot histogram for each channel
for chan, color in zip(channels, colors):
    hist = cv2.calcHist([chan], [0], None, [256], [0, 256])
    plt.plot(hist, color=color)
    plt.xlim([0, 256])

plt.title("RGB Channel Histograms")
plt.xlabel("Pixel Value")
plt.ylabel("Frequency")
plt.grid(True)
plt.show()

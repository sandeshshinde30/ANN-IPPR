# 15) Write a code for applying threshold in the image.
# Input: Gray scale 8 bit image and Threshold Value
# Expected output: Binary Image after applying threshold

import cv2
import numpy as np

# Load the grayscale image (8-bit)
image = cv2.imread('input_image.jpg', cv2.IMREAD_GRAYSCALE)

if image is None:
    print("Error: Image not found or could not be opened.")
    exit()

# Define the threshold value
threshold_value = 128  # You can change this value

# Apply binary thresholding
_, binary_image = cv2.threshold(image, threshold_value, 255, cv2.THRESH_BINARY)

# Save the result
cv2.imwrite('binary_image.jpg', binary_image)

# Display images
cv2.imshow("Original Image", image)
cv2.imshow("Binary Image after Thresholding", binary_image)

cv2.waitKey(0)
cv2.destroyAllWindows()
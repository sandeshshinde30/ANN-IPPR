# 17) Write a code for demonstrating Intensity slicing in the Image.
# Apply Gray-level slicing:- Highlighting specific range of intensity values.
# Input: Gray scale 8 bit image
# Expected output: Gray scale 8 bit image
# i) With preserving the background
# ii) With Non-preserving the background

import cv2
import numpy as np
import matplotlib.pyplot as plt

def gray_level_slicing(image, min_val, max_val, preserve_background=True):
    """
    Perform gray level slicing on a grayscale image.
    
    Parameters:
    - image: 8-bit grayscale image (NumPy array)
    - min_val: lower bound of intensity range to highlight
    - max_val: upper bound of intensity range to highlight
    - preserve_background: True to retain original background, False to set others to 0
    """
    # Create output image
    output = np.zeros_like(image)

    # Mask for values within the specified range
    mask = (image >= min_val) & (image <= max_val)

    if preserve_background:
        output = image.copy()
        output[mask] = 255  # Highlight the desired range
    else:
        output[mask] = 255  # Only highlight the desired range; others remain 0

    return output

# Load a grayscale image
image = cv2.imread('input_image.jpg', cv2.IMREAD_GRAYSCALE)

# Check if image is loaded
if image is None:
    raise FileNotFoundError("Image file not found. Please check the path.")

# Define intensity range to highlight
min_intensity = 100
max_intensity = 150

# Apply slicing
sliced_preserve = gray_level_slicing(image, min_intensity, max_intensity, True)
sliced_no_preserve = gray_level_slicing(image, min_intensity, max_intensity, False)

# Display results using matplotlib
plt.figure(figsize=(12, 4))
plt.subplot(1, 3, 1)
plt.title('Original Image')
plt.imshow(image, cmap='gray')
plt.axis('off')

plt.subplot(1, 3, 2)
plt.title('With Background')
plt.imshow(sliced_preserve, cmap='gray')
plt.axis('off')

plt.subplot(1, 3, 3)
plt.title('Without Background')
plt.imshow(sliced_no_preserve, cmap='gray')
plt.axis('off')

plt.tight_layout()
plt.show()